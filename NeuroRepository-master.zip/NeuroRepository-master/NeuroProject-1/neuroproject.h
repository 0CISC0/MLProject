#ifndef NEUROPROJECT_H
#define NEUROPROJECT_H

enum NTypeEnum {NTypeFloat, NTypeDouble, NTypeInt};

#endif // NEUROPROJECT_H

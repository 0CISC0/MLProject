package first_task_package;

public class Lit {
    private String title;
    private Integer pageCount;

    public Lit(String title, Integer pageCount) {
        this.title = title;
        this.pageCount = pageCount;
    }

    public Lit(){}

    public String getTitle() {
        return title;
    }

    public Integer getPageCount() {
        return pageCount;
    }
}

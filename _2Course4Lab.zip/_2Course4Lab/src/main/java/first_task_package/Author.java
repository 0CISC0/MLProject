package first_task_package;

import java.util.ArrayList;

public class Author {
    private String name;
    private ArrayList<Lit> books;

    public Author(){}

    public Author(String name, ArrayList<Lit> books) {
        this.name = name;
        this.books = books;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Lit> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Lit> books) {
        this.books = books;
    }
}

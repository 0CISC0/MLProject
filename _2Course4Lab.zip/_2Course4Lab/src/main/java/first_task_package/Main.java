package first_task_package;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static ArrayList<Author> AUTHORS;

    public Main() throws IOException {
    }

    public static void main(String[] args) throws IOException {
        ObjectMapper jsonMapper = new ObjectMapper();
        AUTHORS = jsonMapper.readValue(new File("src/main/resources/first_task.json"), new TypeReference<ArrayList<Author>>(){});

        Integer commonPC = 0;
        for(Author item: AUTHORS){
            System.out.println("Имя " + item.getName());
            for(Lit lit: item.getBooks()){
                System.out.println("Title " + lit.getTitle() + "page count " + lit.getPageCount());
                commonPC += lit.getPageCount();
            }
        }
        System.out.println("Common page count: " + commonPC);
        ArrayList<Lit> gor_lits = new ArrayList<>();
        gor_lits.add(new Lit("Na dne", 100));
        AUTHORS.add(new Author("M. Gorkyi", gor_lits));
        for(Author item: AUTHORS){
            if(item.getName().equals(new String("L.N. Tolstoy"))){
                ArrayList<Lit> temp = item.getBooks();
                temp.add(new Lit("Анна Каренина", 600));
                temp.add(new Lit("Кавказский пленник", 400));
                item.setBooks(temp);
            }
        }
        jsonMapper.writeValue(new File("src/main/resources/new_first_task.json"), AUTHORS);
        JsonFactory jfactory = new JsonFactory();
        JsonParser jParser = jfactory.createParser(new File("src/main/resources/new_first_task.json"));
        String fieldname = "";
        while (jParser.nextToken() != null) {
            fieldname = jParser.getCurrentName();
            if ("name".equals(fieldname)) {
                jParser.nextToken();
                System.out.println(jParser.getText());
            }
        }
    }
}

package sec_task_package;

public class Event {
    private String place;
    private Integer year;
    private Integer result;
    private String award;

    public Event(String place, Integer year, Integer result, String award) {
        this.place = place;
        this.year = year;
        this.result = result;
        this.award = award;
    }

    public Event(){}

    public String getPlace() {
        return place;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getResult() {
        return result;
    }

    public String getAward() {
        return award;
    }
}

package sec_task_package;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Sportsman {
    private String name;
    private String birthday;
    private char sex;
    private ArrayList<Event> events;

    public Sportsman(String name, String birthday, char sex, ArrayList<Event> events) {
        this.name = name;
        this.birthday = birthday;
        this.sex = sex;
        this.events = events;
    }

    public Sportsman(){}

    public String getName() {
        return name;
    }

    public Date getBirthday() throws ParseException {
        SimpleDateFormat textFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate = null;

        birthDate = textFormat.parse(birthday);
        return birthDate;
    }

    public char getSex() {
        return sex;
    }

    public ArrayList<Event> getEvents() {
        return events;
    }

    public Integer getCommonResult(){
        Integer commonRes = 0;
        for(Event item: events){
            commonRes += item.getResult();
        }
        return commonRes;
    }
}

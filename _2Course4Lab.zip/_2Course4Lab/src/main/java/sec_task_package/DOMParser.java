package sec_task_package;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import first_task_package.Author;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class DOMParser {
    public static ArrayList<Sportsman> getSportsmanObjects(NodeList sportsmanElements){
        ArrayList<Sportsman> sportsmans = new ArrayList<>();
        for(int i = 0; i < sportsmanElements.getLength(); i++){
            Element sportsmanEl = (Element) sportsmanElements.item(i);
            NamedNodeMap sportsmanAttr = sportsmanElements.item(i).getAttributes();
            sportsmans.add(new Sportsman(sportsmanAttr.getNamedItem("name").getNodeValue(),
                    sportsmanAttr.getNamedItem("birthday").getNodeValue(),
                    sportsmanAttr.getNamedItem("s").getNodeValue().charAt(0),
                    getEventObjects(sportsmanEl.getElementsByTagName("event"))));
        }
        return sportsmans;
    }
    public static ArrayList<Event> getEventObjects(NodeList eventElements){
        ArrayList<Event> events = new ArrayList<>();
        for(int i = 0; i < eventElements.getLength(); i++){
            NamedNodeMap eventAttr = eventElements.item(i).getAttributes();
            Element eventEl = (Element) eventElements.item(i);
            events.add(new Event(eventAttr.getNamedItem("place").getNodeValue(),
                    Integer.parseInt(eventAttr.getNamedItem("year").getNodeValue()),
                    Integer.parseInt(eventEl.getElementsByTagName("result").item(0).getTextContent()),
                    eventEl.getElementsByTagName("award").item(0).getTextContent()));
        }
        return events;
    }

    public static Sportsman addNewSportsman(){
        Scanner input = new Scanner(System.in);
        String name;
        String birhday;
        char sex;
        Integer eventCount;
        ArrayList<Event> events = new ArrayList<>();

        System.out.println("Введите имя спорстмена: ");
        name = input.next();
        System.out.println("Введите дату рождения спорстмена: ");
        birhday = input.next();
        System.out.println("Введите пол спорстмена: ");
        sex = input.next().charAt(0);
        System.out.println("Введите количество соревнований спорстмена: ");
        eventCount = input.nextInt();
        for(int i = 0; i < eventCount; i++){
            events.add(addNewEvent());
        }
        return new Sportsman(name, birhday, sex, events);
    }

    public static Event addNewEvent(){
        Scanner input = new Scanner(System.in);
        String place;
        Integer year;
        Integer result;
        String award;
        System.out.println("Введите место проведения соревнования: ");
        place = input.next();
        System.out.println("Введите год проведения соревнования: ");
        year = input.nextInt();
        System.out.println("Введите результат спорстмена: ");
        result = input.nextInt();
        System.out.println("Введите место, которое занял спорстмен: ");
        award = input.next();
        return new Event(place, year, result, award);
    }

    public static void addNewElement(Document doc, Element root, String name, String value){
        Element firstname = doc.createElement(name);
        firstname.appendChild(doc.createTextNode(value));
        root.appendChild(firstname);
    }
    public static void addNewAttribute(Document doc, Element root, String name, String value){
        Attr attr = doc.createAttribute(name);
        attr.setValue(value);
        root.setAttributeNode(attr);
    }

    public static void createParametrizedJSON(ArrayList<Sportsman> sportsmans) throws IOException, ParseException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        JsonFactory jfactory = new JsonFactory();
        JsonGenerator jGenerator = jfactory
                .createGenerator(new File("src/main/resources/new_sec_task.json"), JsonEncoding.UTF8);
        jGenerator.writeStartArray();
        for(Sportsman item: sportsmans){
            jGenerator.writeStartObject();
            jGenerator.writeStringField("name", item.getName());
            jGenerator.writeStringField("sex", String.valueOf(item.getSex()));
            jGenerator.writeStringField("birthday", item.getBirthday().toString());
            jGenerator.writeEndObject();
        }
        jGenerator.writeEndArray();
        jGenerator.close();
    }

    private static ArrayList<Sportsman> SPORTSMANS = new ArrayList<>();

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, ParseException, TransformerException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        ObjectMapper jsonMapper = new ObjectMapper();


        DocumentBuilder builder = factory.newDocumentBuilder();

        Document document = builder.parse(new File("src/main/resources/sec_task.xml"));

        NodeList sportsmanElements = document.getDocumentElement().getElementsByTagName("sportsman");

        SPORTSMANS = getSportsmanObjects(sportsmanElements);

        System.out.println("Имена спортсменов мужчин: ");
        for(Sportsman item: SPORTSMANS){
            if(item.getSex() == 'м'){
                System.out.println(item.getName());
            }
        }
        System.out.println("**************************************************");

        for(Sportsman item: SPORTSMANS){
            if(item.getSex() == 'ж'){
                System.out.println("Имя спортсменки: " + item.getName() + ", " + "Год рождения: " + item.getBirthday().toString() + ", " + "Кол-во медалей: " + item.getEvents().size());
            }
        }

        System.out.println("**************************************");

        for(Sportsman item: SPORTSMANS){
            for(Event event: item.getEvents()){
                if(event.getPlace().equals(new String("москва")) && event.getYear() == 2002){
                    System.out.println("Имя спортсмена: " + item.getName() + ", " + "Результат: " + event.getResult());
                }
            }
        }
        SPORTSMANS.add(addNewSportsman());

        Document doc = builder.newDocument();
        Element rootElement = doc.createElement("team");
        doc.appendChild(rootElement);
        for(Sportsman item: SPORTSMANS){
            Element sportsman = doc.createElement("Sportsman");
            rootElement.appendChild(sportsman);

            addNewAttribute(doc, sportsman, "name", item.getName());
            addNewElement(doc, sportsman, "eventCount", String.valueOf(item.getEvents().size()));
            addNewElement(doc, sportsman, "commonResult", String.valueOf(item.getCommonResult()));
        }

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File("src/main/resources/file.xml"));

        transformer.transform(source, result);

        System.out.println("File saved!");

        jsonMapper.writeValue(new File("src/main/resources/sec_task.json"), SPORTSMANS);
        createParametrizedJSON(SPORTSMANS);
    }
}
